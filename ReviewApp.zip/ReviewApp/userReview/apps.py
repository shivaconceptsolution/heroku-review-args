from django.apps import AppConfig


class UserreviewConfig(AppConfig):
    name = 'userReview'
